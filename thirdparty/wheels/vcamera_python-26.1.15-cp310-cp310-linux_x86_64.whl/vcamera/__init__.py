"""vcamera package initializer for wheel installs."""

import os
import platform
import warnings

_DLL_DIR_HANDLE = None


def _prepend_env_path(var_name, value, sep):
    current = os.environ.get(var_name, "")
    if not current:
        os.environ[var_name] = value
        return

    items = current.split(sep)
    if value not in items:
        os.environ[var_name] = f"{value}{sep}{current}"


def _configure_runtime_dir():
    global _DLL_DIR_HANDLE

    lib_dir = os.path.dirname(os.path.abspath(__file__))
    system_name = platform.system()

    if system_name == "Windows":
        if hasattr(os, "add_dll_directory"):
            try:
                _DLL_DIR_HANDLE = os.add_dll_directory(lib_dir)
            except OSError as exc:
                warnings.warn(f"Failed to register DLL directory: {exc}", RuntimeWarning)
        _prepend_env_path("PATH", lib_dir, ";")
    elif system_name == "Linux":
        _prepend_env_path("LD_LIBRARY_PATH", lib_dir, ":")
    elif system_name == "Darwin":
        _prepend_env_path("DYLD_LIBRARY_PATH", lib_dir, ":")


_configure_runtime_dir()

from vcamera._VcameraPy import *  # noqa: F401, F403, E402